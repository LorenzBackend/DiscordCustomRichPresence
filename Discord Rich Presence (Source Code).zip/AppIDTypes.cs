﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
public class AppIDTypes {
    public const string NetflixID = "824039459107635221";
    public const string YouTubeID = "824039839862620170";
    public const string TwitchID = "824040496333586433";
    public const string Photoshop = "824407566586871809";
    public const string AfterEffects = "824408058209894411";
    public const string PremierePro = "824408500469366856";
    public const string xD = "824408809187311637";
    public const string Word = "824409220044423168";
    public const string Excel = "824409824421871640";
    public const string PowerPoint = "824410084108795955";
    public const string Unity = "824410893826654278";
    public const string UnrealEngine = "825763513837944923";
    public const string SoundCloud = "827596147374686329";
}

