﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class ServiceSettings {
    public static bool customMode = false;
    public static bool AppMode = false;
    public static bool BrowserMode = false;
}
